Kami terdiri dari 4 orang yaitu :
1. Ivan Taufiqurrahman
2. Jodhi Chrisnandi
3. Michael Renu
4. Yudi Arif Firmansyah

Program ini dibuat untuk memenuhi tugas akhir dari mata kuliah Algoritma dan Pemograman.
Program ini dibuat dengan didasarkan materi-materi yang telah kami terima selama semester 1.
Program ini dibuat untuk memudahkan dalam pemesanan tiket pesawat.
Cara kerja program ini adalah :
1. Program akan menampilkan daftar kota tujuan yang ingin dituju
2. User memilih kota yang ingin dituju
3. Setelah dipilih kota tujuan, program akan menampilkan daftar maskapai penerbangan beserta harga tiketnya
4. User memilih kode maskapai
5. User memasukkan jumlah tiket yang diinginkan
6. User memasukkan jumlah berapa orang yang ingin memesan tiket
7. User memasukkan nama
8. Tiket berhasil dipesan
